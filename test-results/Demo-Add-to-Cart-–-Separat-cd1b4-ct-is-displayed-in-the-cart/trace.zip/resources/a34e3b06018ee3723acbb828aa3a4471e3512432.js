
    (function() {
      var cdnOrigin = "https://cdn.shopify.com";
      var scripts = ["/cdn/shopifycloud/checkout-web/assets/c1/polyfills.BVYsYAdG.js","/cdn/shopifycloud/checkout-web/assets/c1/app.CRTQfUS9.js","/cdn/shopifycloud/checkout-web/assets/c1/locale-en.DETTyoNa.js","/cdn/shopifycloud/checkout-web/assets/c1/page-OnePage.B7rJIcoM.js","/cdn/shopifycloud/checkout-web/assets/c1/LocalizationExtensionField.tP7eb-U9.js","/cdn/shopifycloud/checkout-web/assets/c1/RememberMeDescriptionText.CWyX9OVC.js","/cdn/shopifycloud/checkout-web/assets/c1/ShopPayOptInDisclaimer.CQ8cWfJ_.js","/cdn/shopifycloud/checkout-web/assets/c1/PaymentButtons.NialZMlr.js","/cdn/shopifycloud/checkout-web/assets/c1/StockProblemsLineItemList.98uN-yDp.js","/cdn/shopifycloud/checkout-web/assets/c1/LocalPickup.B-Pzqstu.js","/cdn/shopifycloud/checkout-web/assets/c1/useShopPayButtonClassName.BgpTzYaN.js","/cdn/shopifycloud/checkout-web/assets/c1/VaultedPayment.Dz8spdfz.js","/cdn/shopifycloud/checkout-web/assets/c1/SeparatePaymentsNotice.FmNmDFMN.js","/cdn/shopifycloud/checkout-web/assets/c1/useAddressManager.DwxB9Rqj.js","/cdn/shopifycloud/checkout-web/assets/c1/useShopPayPaymentRequiredMethod.CD6AUPOu.js","/cdn/shopifycloud/checkout-web/assets/c1/PayButtonSection.Bao4gh8U.js","/cdn/shopifycloud/checkout-web/assets/c1/ShipmentBreakdown.BsWmb_Hn.js","/cdn/shopifycloud/checkout-web/assets/c1/MerchandiseModal.M-dDJbmH.js","/cdn/shopifycloud/checkout-web/assets/c1/StackedMerchandisePreview.DhwvbBD8.js","/cdn/shopifycloud/checkout-web/assets/c1/component-ShopPayVerificationSwitch.DdxBF1pk.js","/cdn/shopifycloud/checkout-web/assets/c1/useSubscribeMessenger.CCcxOAux.js","/cdn/shopifycloud/checkout-web/assets/c1/index.BYdsbtjm.js"];
      var styles = ["/cdn/shopifycloud/checkout-web/assets/c1/assets/app.BZ2fo6mG.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/OnePage.CxYkJKrl.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/LocalizationExtensionField.Ca9titpM.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/LocalPickup.Cuz4ryjJ.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/ShopPayVerificationSwitch.WW3cs_z5.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useShopPayButtonClassName.CBpWLJzT.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/VaultedPayment.OxMVm7u-.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/StackedMerchandisePreview.D6OuIVjc.css"];
      var fontPreconnectUrls = [];
      var fontPrefetchUrls = [];
      var imgPrefetchUrls = [];

      function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
      }

      function preconnectAssets() {
        var resources = [cdnOrigin].concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) preconnect(res, next);
        })();
      }

      function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
          link.rel = 'prefetch';
          link.fetchPriority = 'low';
          link.as = as;
          if (as === 'font') link.type = 'font/woff2';
          link.href = url;
          link.crossOrigin = '';
          link.onload = link.onerror = callback;
          document.head.appendChild(link);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', url, true);
          xhr.onloadend = callback;
          xhr.send();
        }
      }

      function prefetchAssets() {
        var resources = [].concat(
          scripts.map(function(url) { return [url, 'script']; }),
          styles.map(function(url) { return [url, 'style']; }),
          fontPrefetchUrls.map(function(url) { return [url, 'font']; }),
          imgPrefetchUrls.map(function(url) { return [url, 'image']; })
        );
        var index = 0;
        function run() {
          var res = resources[index++];
          if (res) prefetch(res[0], res[1], next);
        }
        var next = (self.requestIdleCallback || setTimeout).bind(self, run);
        next();
      }

      function onLoaded() {
        try {
          if (parseFloat(navigator.connection.effectiveType) > 2 && !navigator.connection.saveData) {
            preconnectAssets();
            prefetchAssets();
          }
        } catch (e) {}
      }

      if (document.readyState === 'complete') {
        onLoaded();
      } else {
        addEventListener('load', onLoaded);
      }
    })();
  