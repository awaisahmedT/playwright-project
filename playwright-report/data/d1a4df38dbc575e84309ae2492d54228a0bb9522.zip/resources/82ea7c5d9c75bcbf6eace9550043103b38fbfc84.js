
    (function() {
      var cdnOrigin = "https://cdn.shopify.com";
      var scripts = ["/cdn/shopifycloud/checkout-web/assets/c1/polyfills.BVYsYAdG.js","/cdn/shopifycloud/checkout-web/assets/c1/app.OHfx2ugd.js","/cdn/shopifycloud/checkout-web/assets/c1/locale-en.NFT7mTMc.js","/cdn/shopifycloud/checkout-web/assets/c1/page-OnePage.B22VyVoJ.js","/cdn/shopifycloud/checkout-web/assets/c1/LocalizationExtensionField.Dhp8ZY4a.js","/cdn/shopifycloud/checkout-web/assets/c1/RememberMeDescriptionText.D7NzEPg_.js","/cdn/shopifycloud/checkout-web/assets/c1/ShopPayOptInDisclaimer.lQRhGtCY.js","/cdn/shopifycloud/checkout-web/assets/c1/PaymentButtons.CXmmPxy2.js","/cdn/shopifycloud/checkout-web/assets/c1/StockProblemsLineItemList.B1sakAaq.js","/cdn/shopifycloud/checkout-web/assets/c1/LocalPickup.B_mUg-44.js","/cdn/shopifycloud/checkout-web/assets/c1/useShopPayButtonClassName.Be3Pc0_N.js","/cdn/shopifycloud/checkout-web/assets/c1/VaultedPayment.BZjmg4q9.js","/cdn/shopifycloud/checkout-web/assets/c1/SeparatePaymentsNotice.CAH-pFMn.js","/cdn/shopifycloud/checkout-web/assets/c1/useAddressManager.Bjt8EI5e.js","/cdn/shopifycloud/checkout-web/assets/c1/useShopPayPaymentRequiredMethod.BoUnRSbq.js","/cdn/shopifycloud/checkout-web/assets/c1/PayButtonSection.BRy6Fg-5.js","/cdn/shopifycloud/checkout-web/assets/c1/ShipmentBreakdown.D5wqO1sH.js","/cdn/shopifycloud/checkout-web/assets/c1/MerchandiseModal.BFe8qX7c.js","/cdn/shopifycloud/checkout-web/assets/c1/StackedMerchandisePreview.CgErlCe3.js","/cdn/shopifycloud/checkout-web/assets/c1/component-ShopPayVerificationSwitch.RULzzqTL.js","/cdn/shopifycloud/checkout-web/assets/c1/useSubscribeMessenger.Z2M0l9hb.js","/cdn/shopifycloud/checkout-web/assets/c1/index.BdMtQkK7.js"];
      var styles = ["/cdn/shopifycloud/checkout-web/assets/c1/assets/app.CjGn_Lz5.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/OnePage.BE3bhd3W.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/LocalizationExtensionField.Ca9titpM.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/LocalPickup.Cuz4ryjJ.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/ShopPayVerificationSwitch.WW3cs_z5.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useShopPayButtonClassName.CBpWLJzT.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/VaultedPayment.OxMVm7u-.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/StackedMerchandisePreview.D6OuIVjc.css"];
      var fontPreconnectUrls = [];
      var fontPrefetchUrls = [];
      var imgPrefetchUrls = [];

      function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
      }

      function preconnectAssets() {
        var resources = [cdnOrigin].concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) preconnect(res, next);
        })();
      }

      function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
          link.rel = 'prefetch';
          link.fetchPriority = 'low';
          link.as = as;
          if (as === 'font') link.type = 'font/woff2';
          link.href = url;
          link.crossOrigin = '';
          link.onload = link.onerror = callback;
          document.head.appendChild(link);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', url, true);
          xhr.onloadend = callback;
          xhr.send();
        }
      }

      function prefetchAssets() {
        var resources = [].concat(
          scripts.map(function(url) { return [url, 'script']; }),
          styles.map(function(url) { return [url, 'style']; }),
          fontPrefetchUrls.map(function(url) { return [url, 'font']; }),
          imgPrefetchUrls.map(function(url) { return [url, 'image']; })
        );
        var index = 0;
        function run() {
          var res = resources[index++];
          if (res) prefetch(res[0], res[1], next);
        }
        var next = (self.requestIdleCallback || setTimeout).bind(self, run);
        next();
      }

      function onLoaded() {
        try {
          if (parseFloat(navigator.connection.effectiveType) > 2 && !navigator.connection.saveData) {
            preconnectAssets();
            prefetchAssets();
          }
        } catch (e) {}
      }

      if (document.readyState === 'complete') {
        onLoaded();
      } else {
        addEventListener('load', onLoaded);
      }
    })();
  